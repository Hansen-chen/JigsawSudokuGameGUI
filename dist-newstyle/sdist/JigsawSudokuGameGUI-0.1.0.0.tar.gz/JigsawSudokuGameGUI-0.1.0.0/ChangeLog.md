# Changelog for JigsawSudokuGameGUI

## Unreleased changes
